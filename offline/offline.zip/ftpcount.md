ftpcount
===

显示目前已FTP登入的用户人数

## 补充说明

显示目前已ftp登入的用户人数。执行这项指令可得知目前用FTP登入系统的人数以及FTP登入人数的上限。

语法：

```shell
ftpcount
```


