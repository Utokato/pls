error code: 502
