rpmdb
===

初始化和重建RPM数据库

## 补充说明

**rpmdb命令** 用于初始化和重建rpm数据库。

###  语法

```shell
rpmdb(选项)
```

###  选项

```shell
--initdb：初始化RPM数据库；
--rebuilddb：从已安装的包头文件，反向重建RPM数据库。
```


