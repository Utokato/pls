bye
===

命令用于中断FTP连线并结束程序

## 补充说明

**bye命令** 在ftp模式下，输入bye即可中断目前的连线作业，并结束ftp的执行。


###  语法

```shell
bye
```

### 实例

```shell
bye
```
