rcconf
===

Debian Linux下的运行等级服务配置工具

## 补充说明

**rcconf命令** 是Debian Linux下的运行等级服务配置工具，用以设置在特定的运行等级下系统服务的启动配置。

###  语法

```shell
rcconf(选项)
```

###  选项

```shell
--help：打印帮助信息；
--dialog：使用对话命令显示菜单；
--notermcheck：不按照终端属性来设置窗口尺寸。
```


