ip6tables-restore
===

还原ip6tables表

## 补充说明

**ip6tables-restore命令** 用来还原ip6tables表。

###  语法

```shell
ip6tables-restore(选项)
```

###  选项

```shell
-c：指定在还原iptables表时，还原当前的数据包计数器和字节计数器值；
-t：指定要还原的表的名称。
```


