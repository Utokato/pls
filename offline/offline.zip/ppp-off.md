ppp-off
===

关闭ppp连线

## 补充说明

这是Slackware发行版内附的程序，让用户切断PPP的网络连线。

###  语法

```shell
ppp-off
```


