sftp-server
===

sftp协议的服务器端程序

## 补充说明

**sftp-server命令** 是一个“sftp”协议的服务器端程序，它使用加密的方式进行文件传输。

###  语法

```shell
sftp-server
```


