logout
===

退出当前登录的Shell

## 补充说明

**logout命令** 用于退出当前登录的Shell，logout指令让用户退出系统，其功能和login指令相互对应。

###  语法

```shell
logout
```


